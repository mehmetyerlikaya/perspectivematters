import { useState, useEffect } from "react";
import PostCard from "./PostCard";
import { Skeleton } from "./ui/skeleton";

const SAMPLE_POSTS = [
  {
    title: "The Art of Perspective Taking",
    date: "March 15, 2024",
    tags: ["Life", "Philosophy"],
  },
  {
    title: "Finding Beauty in Different Viewpoints",
    date: "March 10, 2024",
    tags: ["Mindfulness"],
  },
  {
    title: "Why Perspective Changes Everything",
    date: "March 5, 2024",
    tags: ["Thoughts"],
  },
];

interface PostListProps {
  selectedTag?: string | null;
}

const PostList = ({ selectedTag }: PostListProps) => {
  const [loading, setLoading] = useState(true);
  const [posts, setPosts] = useState<typeof SAMPLE_POSTS>([]);

  useEffect(() => {
    // Simulate loading delay
    setTimeout(() => {
      setPosts(SAMPLE_POSTS);
      setLoading(false);
    }, 1500);
  }, []);

  const filteredPosts = selectedTag
    ? posts.filter(post => post.tags.includes(selectedTag))
    : posts;

  if (loading) {
    return (
      <div className="divide-y divide-blog-purple/10 bg-white/50 rounded-lg shadow-sm">
        {[1, 2, 3].map((i) => (
          <div key={i} className="p-6 space-y-3">
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-6 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="divide-y divide-blog-purple/10 bg-white/50 rounded-lg shadow-sm">
      {filteredPosts.map((post) => (
        <PostCard key={post.title} {...post} />
      ))}
    </div>
  );
};

export default PostList;