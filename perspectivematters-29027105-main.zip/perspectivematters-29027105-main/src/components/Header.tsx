import { useState } from "react";
import { Button } from "./ui/button";

const TAGS = ["Life", "Philosophy", "Mindfulness", "Thoughts"];
const TAG_EMOJIS: { [key: string]: string } = {
  Life: "🌱",
  Philosophy: "🤔",
  Mindfulness: "🧘",
  Thoughts: "💭",
};

interface HeaderProps {
  onTagSelect: (tag: string | null) => void;
}

const Header = ({ onTagSelect }: HeaderProps) => {
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [language, setLanguage] = useState<string>("en");

  const handleTagClick = (tag: string) => {
    const newTag = tag === selectedTag ? null : tag;
    setSelectedTag(newTag);
    onTagSelect(newTag);
  };

  return (
    <header className="py-8 mb-12 border-b bg-gradient-to-r from-blog-purple/10 to-blog-blue/10">
      <div className="container">
        <div className="flex justify-end mb-4 space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLanguage("en")}
            className={`${
              language === "en"
                ? "bg-blog-purple/20 text-blog-purple"
                : "text-blog-text/70 hover:text-blog-purple"
            }`}
          >
            EN
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLanguage("de")}
            className={`${
              language === "de"
                ? "bg-blog-purple/20 text-blog-purple"
                : "text-blog-text/70 hover:text-blog-purple"
            }`}
          >
            DE
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLanguage("tr")}
            className={`${
              language === "tr"
                ? "bg-blog-purple/20 text-blog-purple"
                : "text-blog-text/70 hover:text-blog-purple"
            }`}
          >
            TR
          </Button>
        </div>
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="flex-1">
            <h1 className="text-4xl font-light tracking-wide text-blog-text mb-4">
              Perspective Matters
            </h1>
            <p className="text-blog-text">
              <span className="text-blog-purple italic">Random thoughts</span>
              <span className="text-blog-text">, </span>
              <span className="text-blog-blue italic">ideas</span>
              <span className="text-blog-text">, and </span>
              <span className="text-blog-accent italic">projects</span>
              <span className="text-blog-text">.</span>
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {TAGS.map((tag) => (
                <Button
                  key={tag}
                  variant="ghost"
                  className={`
                    px-4 py-2 rounded-full text-sm transition-all duration-300
                    ${selectedTag === tag 
                      ? 'bg-blog-purple/20 text-blog-purple' 
                      : 'hover:bg-blog-purple/10 text-blog-text/70 hover:text-blog-purple'
                    }
                  `}
                  onClick={() => handleTagClick(tag)}
                >
                  {TAG_EMOJIS[tag]} {tag}
                </Button>
              ))}
            </div>
          </div>
          <div className="flex-1">
            <img
              src="/lovable-uploads/d2cfa19f-e451-4c14-9d00-d34fb0f5be31.png"
              alt="Cozy writing environment"
              className="rounded-lg shadow-lg w-full max-w-md mx-auto"
            />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;