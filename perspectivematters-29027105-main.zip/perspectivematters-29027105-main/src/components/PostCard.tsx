import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "./ui/collapsible";
import { calculateReadingTime } from "@/utils/readingTime";

const TAG_EMOJIS: { [key: string]: string } = {
  Life: "🌱",
  Philosophy: "🤔",
  Mindfulness: "🧘",
  Thoughts: "💭",
};

interface PostCardProps {
  title: string;
  date: string;
  tags: string[];
}

const PostCard = ({ title, date, tags }: PostCardProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  const handlePostClick = () => {
    navigate(`/post/${encodeURIComponent(title.toLowerCase().replace(/ /g, "-"))}`);
  };

  // Sample preview text (in a real app, this would come from the actual post content)
  const previewText = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.";
  const readingTime = calculateReadingTime(previewText);

  return (
    <article 
      className="py-6 px-4 group cursor-pointer hover:bg-blog-purple/5 transition-all animate-fade-in"
      onClick={handlePostClick}
    >
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-2 flex-wrap">
          <time className="text-sm text-blog-date">{date}</time>
          <span className="text-sm text-blog-date">•</span>
          <span className="text-sm text-blog-date">{readingTime}</span>
          {tags.map((tag) => (
            <span
              key={tag}
              className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs rounded-full bg-blog-tag text-blog-purple hover:scale-105 transition-transform"
            >
              {TAG_EMOJIS[tag] || "📌"} {tag}
            </span>
          ))}
        </div>
        <h2 className="text-xl font-medium text-blog-text group-hover:text-blog-accent transition-colors">
          {title}
        </h2>
        <Collapsible open={isOpen} onOpenChange={setIsOpen} onClick={(e) => e.stopPropagation()}>
          <CollapsibleTrigger className="text-sm text-blog-purple hover:text-blog-accent transition-colors">
            {isOpen ? "Read less" : "Read more"}
          </CollapsibleTrigger>
          <CollapsibleContent className="text-blog-text/80 text-sm mt-2 animate-accordion-down">
            {previewText}
          </CollapsibleContent>
        </Collapsible>
      </div>
    </article>
  );
};

export default PostCard;