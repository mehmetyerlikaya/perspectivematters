import { useState } from "react";
import Header from "@/components/Header";
import PostList from "@/components/PostList";

const Index = () => {
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-blog-purple/5 to-blog-blue/5">
      <Header onTagSelect={setSelectedTag} />
      <main className="container pb-12">
        <PostList selectedTag={selectedTag} />
      </main>
    </div>
  );
};

export default Index;