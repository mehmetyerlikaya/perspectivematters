import { useParams, Link } from "react-router-dom";
import { calculateReadingTime } from "@/utils/readingTime";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";

const BLOG_POSTS = {
  "the-art-of-perspective-taking": {
    title: "The Art of Perspective Taking",
    date: "March 15, 2024",
    tags: ["Life", "Philosophy"],
    content: `
      Understanding different perspectives is an art that requires practice, patience, and empathy. 
      When we take the time to see things from another person's point of view, we expand our own 
      understanding of the world and develop deeper connections with others.

      This skill becomes increasingly important in our interconnected world, where diverse viewpoints 
      and experiences shape our daily interactions. By cultivating perspective-taking abilities, we 
      can bridge gaps in understanding and foster more meaningful relationships.

      The process begins with active listening and suspending our own judgments. It involves asking 
      thoughtful questions and being genuinely curious about others' experiences. Through this practice, 
      we not only learn about different viewpoints but also challenge and refine our own beliefs.
    `,
  },
  "finding-beauty-in-different-viewpoints": {
    title: "Finding Beauty in Different Viewpoints",
    date: "March 10, 2024",
    tags: ["Mindfulness"],
    content: `
      Beauty exists in the diversity of human perspectives. Each unique viewpoint adds a new color 
      to the canvas of our collective understanding. When we embrace this diversity, we enrich our 
      own experience of the world.

      Different viewpoints challenge our assumptions and push us to grow. They reveal blind spots 
      in our thinking and open new possibilities we might never have considered. This is where true 
      learning and personal growth begin.

      The practice of finding beauty in different viewpoints requires openness and vulnerability. 
      It asks us to set aside our preconceptions and approach each new perspective with curiosity 
      and respect.
    `,
  },
  "why-perspective-changes-everything": {
    title: "Why Perspective Changes Everything",
    date: "March 5, 2024",
    tags: ["Thoughts"],
    content: `
      Our perspective shapes everything about how we experience the world. It influences our decisions, 
      relationships, and the opportunities we see. Understanding this power gives us the ability to 
      consciously shift our viewpoint when needed.

      Sometimes, a simple shift in perspective can transform a challenge into an opportunity or turn 
      a conflict into a chance for connection. This mental flexibility is a crucial skill in navigating 
      our complex modern world.

      By recognizing that our perspective is just one of many possible ways to see a situation, we 
      become more adaptable and resilient. This awareness allows us to choose the most helpful viewpoint 
      for any given situation.
    `,
  },
};

const BlogPost = () => {
  const { slug } = useParams();
  const post = slug ? BLOG_POSTS[slug as keyof typeof BLOG_POSTS] : null;

  if (!post) {
    return (
      <div className="container py-12">
        <h1 className="text-2xl font-bold text-blog-text">Post not found</h1>
      </div>
    );
  }

  const readingTime = calculateReadingTime(post.content);

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-blog-purple/5 to-blog-blue/5">
      <div className="container max-w-3xl py-12">
        <Link to="/">
          <Button
            variant="ghost"
            className="mb-8 text-blog-purple hover:text-blog-blue hover:bg-blog-purple/10 transition-colors"
          >
            <Home className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
        </Link>
        <article className="prose prose-lg mx-auto bg-white/50 rounded-lg shadow-sm p-8">
          <header className="mb-8">
            <div className="flex items-center gap-2 text-blog-date mb-4">
              <time>{post.date}</time>
              <span>•</span>
              <span>{readingTime}</span>
            </div>
            <h1 className="text-4xl font-bold text-blog-text mb-4">{post.title}</h1>
            <div className="flex gap-2">
              {post.tags.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs rounded-full bg-blog-tag text-blog-purple"
                >
                  {tag}
                </span>
              ))}
            </div>
          </header>
          <div className="text-blog-text whitespace-pre-line">
            {post.content}
          </div>
        </article>
      </div>
    </div>
  );
};

export default BlogPost;
